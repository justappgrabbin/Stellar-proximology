import { randomBytes, createHash, randomUUID } from 'node:crypto';
import { ResonanceNetwork } from './donors/resonance-network.mjs';

const MAX_TEXT = 6000;
export const ADDRESS_FIELDS = Object.freeze(['planetary','dimension','gate','line','color','tone','base','degree','minute','second','arc','zodiac','house']);
export const OPERATIONS = Object.freeze(['trim','uppercase','lowercase','prefix','suffix','replace_all','slice','word_count']);
const safeText = (value, max = MAX_TEXT) => String(value ?? '').slice(0,max);
const id = (tag) => `${tag}_${randomUUID().replace(/-/g,'').slice(0,14)}`;
const secret = () => randomBytes(24).toString('base64url');
const hash = (s) => createHash('sha256').update(String(s)).digest('hex');
const clone = (v) => structuredClone(v);
const req = (ok,msg) => {if(!ok) throw Object.assign(new Error(msg),{status:400})};

export function validateSteps(steps) {
  req(Array.isArray(steps) && steps.length>=1 && steps.length<=6,'A capability requires 1–6 primitive steps');
  return steps.map(step => {
    req(step && OPERATIONS.includes(step.op),`Unknown approved primitive: ${step?.op}`);
    const o={op:step.op};
    if(['prefix','suffix'].includes(step.op)) { req(typeof step.text==='string' && step.text.length<=200,'Prefix/suffix text must be <=200 characters'); o.text=step.text; }
    if(step.op==='replace_all') {req(typeof step.search==='string' && step.search.length>0 && step.search.length<=100 && typeof step.replacement==='string' && step.replacement.length<=200,'Invalid replacement');o.search=step.search;o.replacement=step.replacement;}
    if(step.op==='slice'){req(Number.isInteger(step.start)&&step.start>=0&&step.start<=MAX_TEXT && Number.isInteger(step.end)&&step.end>=step.start&&step.end<=MAX_TEXT,'Invalid slice bounds');o.start=step.start;o.end=step.end;}
    return o;
  });
}
export function executeSteps(input, steps) {
  let value=safeText(input);const trace=[];
  for(const step of validateSteps(steps)) {
    switch(step.op) {
      case 'trim':value=value.trim();break;
      case 'uppercase':value=value.toUpperCase();break;
      case 'lowercase':value=value.toLowerCase();break;
      case 'prefix':value=step.text+value;break;
      case 'suffix':value=value+step.text;break;
      case 'replace_all':value=value.split(step.search).join(step.replacement);break;
      case 'slice':value=value.slice(step.start,step.end);break;
      case 'word_count':value=String((value.trim().match(/\S+/g)||[]).length);break;
    }
    req(value.length<=MAX_TEXT,'Capability output exceeds bounded region');
    trace.push({primitive:step.op,length:value.length});
  }
  return {output:value,trace};
}
function event(db,type,actor,detail={}) { const e={id:id('evt'),at:new Date().toISOString(),type,actor,detail};db.events.push(e);if(db.events.length>300) db.events.splice(0,db.events.length-300);return e; }
function userFor(db,token){return db.users.find(x=>x.tokenHash===hash(token))||null;}
function projectFor(db,projId){let p=db.projects.find(x=>x.id===projId);req(p,'Unknown project');return p;}
function owner(db,projId,userId){const p=projectFor(db,projId);req(p.ownerId===userId,'Only a project owner may authorize this operation');return p;}
function participant(db,userId){const u=db.users.find(x=>x.id===userId);req(u,'Unknown participant');return u;}
function tokens(v){return [...new Set(String(v||'').toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>2))];}
function observedRelations(db) {
 const network = new ResonanceNetwork();
 for (const item of db.observations||[]) network.observe(item);
 return network.snapshot();
}
function matchOpportunities(db) {
 const result=[];
 for(const a of db.projects) for(const b of db.projects){if(a.id===b.id || a.ownerId===b.ownerId)continue;
 const hits=tokens(a.offers).filter(t=>tokens(b.needs).includes(t));if(hits.length)result.push({from:a.id,to:b.id,evidence:hits,relation:'offers-meets-need'});
 }
 return result;
}
export function createEmptyState(){return {schema:'self-cult.state.v1',users:[],invites:[],projects:[],proposals:[],capabilities:[],events:[],earnings:[],receipts:[],observations:[]};}
export function createEngine(initial=createEmptyState()) {
 const db=clone(initial);
 const requireUser=(token)=>{const u=userFor(db,token);if(!u)throw Object.assign(new Error('Invalid participant token'),{status:401});return u;};
 return {
   db,
   hasParticipants:()=>db.users.length>0,
   authenticate:(token)=>requireUser(token).id,
   setup({bootstrapKey,expectedBootstrapKey,name}){
    req(!db.users.length,'Room is already initialized');req(expectedBootstrapKey && bootstrapKey===expectedBootstrapKey,'Invalid bootstrap key');
    const authToken=secret();const u={id:id('person'),name:safeText(name,65)||'Participant A',role:'founder',tokenHash:hash(authToken),createdAt:new Date().toISOString(),agent:{id:id('agent'),model:'qwen3-0.6b',instructions:'Suggest capabilities; never execute or publish without my approval.',memory:[]}};
    db.users.push(u);event(db,'participant.joined',u.id,{role:u.role});return {participantId:u.id,token:authToken};
   },
   invite(token){const u=requireUser(token);const code=secret();db.invites.push({hash:hash(code),issuer:u.id,expiresAt:Date.now()+86400000,used:false});event(db,'participant.invited',u.id);return {code,expiresInHours:24};},
   join({inviteCode,name}){const iv=db.invites.find(i=>i.hash===hash(inviteCode)&&!i.used&&i.expiresAt>Date.now());req(iv,'Invite invalid, expired or already used');iv.used=true;
    const authToken=secret();const u={id:id('person'),name:safeText(name,65)||'Participant',role:'participant',tokenHash:hash(authToken),createdAt:new Date().toISOString(),agent:{id:id('agent'),model:'tinyllama-1.1b',instructions:'Suggest capabilities; never execute or publish without my approval.',memory:[]}};
    db.users.push(u);event(db,'participant.joined',u.id,{role:u.role});return {participantId:u.id,token:authToken};
   },
   state(token){const u=requireUser(token);return {self:{id:u.id,name:u.name,role:u.role,agent:clone(u.agent)},users:db.users.map(x=>({id:x.id,name:x.name,role:x.role,model:x.agent.model})),projects:clone(db.projects),proposals:clone(db.proposals),capabilities:clone(db.capabilities),events:clone(db.events.slice(-100)),opportunities:matchOpportunities(db),observedRelations:observedRelations(db),earnings:clone(db.earnings.filter(e=>e.reporterId===u.id)),receipts:clone(db.receipts.filter(r=>r.actor===u.id)),operations:OPERATIONS,addressFields:ADDRESS_FIELDS};},
   createProject(token,{name,purpose,offers='',needs='',address=null}){const u=requireUser(token);req(name && String(name).trim().length<=100,'Project name is required (max 100)');
    if(address!==null)req(typeof address==='object' && ADDRESS_FIELDS.every(f=>Object.hasOwn(address,f)) && Object.keys(address).length===13,'Preserve all 13 ontological address fields or leave unresolved');
    const p={id:id('project'),ownerId:u.id,name:safeText(name,100),purpose:safeText(purpose,1000),offers:safeText(offers,350),needs:safeText(needs,350),address:address?clone(address):null,createdAt:new Date().toISOString()};db.projects.push(p);event(db,'project.created',u.id,{projectId:p.id});return clone(p);},
   setAgent(token,{model,instructions}){const u=requireUser(token);req(['qwen3-0.6b','tinyllama-1.1b','none'].includes(model),'Unknown model selection');req(typeof instructions==='string' && instructions.length<=1500,'Invalid instructions');u.agent.model=model;u.agent.instructions=instructions;event(db,'agent.settings',u.id,{model});return {model,instructions};},
   propose(token,{sourceProjectId,targetProjectId=null,name,reason='',steps}){const u=requireUser(token);owner(db,sourceProjectId,u.id);
    if(targetProjectId){req(targetProjectId!==sourceProjectId,'Use a single-project proposal for local capabilities');projectFor(db,targetProjectId);}
    req(typeof name==='string' && name.trim().length>0 && name.length<=100,'Capability name is required');
    const p={id:id('proposal'),createdAt:new Date().toISOString(),authorId:u.id,sourceProjectId,targetProjectId:targetProjectId||null,name:name.trim(),reason:safeText(reason,700),steps:validateSteps(steps),approvals:[],status:'pending',capabilityId:null};
    db.proposals.push(p);event(db,'proposal.created',u.id,{proposalId:p.id});return clone(p);},
   decide(token,{proposalId,decision}){const u=requireUser(token);const p=db.proposals.find(x=>x.id===proposalId);req(p,'Unknown proposal');req(p.status==='pending','Proposal already closed');req(['approve','reject'].includes(decision),'Decision must be approve or reject');
    const sourceOwner=owner(db,p.sourceProjectId,p.authorId);const permitted=[sourceOwner.ownerId];if(p.targetProjectId)permitted.push(projectFor(db,p.targetProjectId).ownerId);
    req(permitted.includes(u.id),'Only impacted project owners can decide');
    if(decision==='reject'){p.status='rejected';event(db,'proposal.rejected',u.id,{proposalId});return clone(p);}
    if(!p.approvals.includes(u.id))p.approvals.push(u.id);
    if([...new Set(permitted)].every(x=>p.approvals.includes(x))){const cap={id:id('capability'),name:p.name,steps:clone(p.steps),ownerProjectId:p.sourceProjectId,availableTo:[p.sourceProjectId,...(p.targetProjectId?[p.targetProjectId]:[])],createdBy:p.authorId,provenance:{proposalId:p.id,approvedBy:[...p.approvals],validatedWith:'approved-primitive-pipeline'},createdAt:new Date().toISOString()};db.capabilities.push(cap);p.capabilityId=cap.id;p.status='published';event(db,'capability.published',u.id,{capabilityId:cap.id,projects:cap.availableTo});}
    else event(db,'proposal.approved',u.id,{proposalId});return clone(p);},
   execute(token,{capabilityId,projectId,input}){const u=requireUser(token);owner(db,projectId,u.id);const cap=db.capabilities.find(c=>c.id===capabilityId);req(cap && cap.availableTo.includes(projectId),'Capability not available in project');
    const result=executeSteps(input,cap.steps);const receipt={id:id('receipt'),actor:u.id,projectId,capabilityId,at:new Date().toISOString(),inputLength:String(input||'').length,outputLength:result.output.length,trace:result.trace};db.receipts.push(receipt);if(cap.ownerProjectId!==projectId){db.observations.push({a:cap.ownerProjectId,b:projectId,outcome:1,type:'verified-capability-exchange',verified:true,evidence:{receiptId:receipt.id}});}event(db,'capability.executed',u.id,{projectId,capabilityId,receiptId:receipt.id});return {...result,receipt};},
   earnings(token,{projectId,amount,contribution=0,note=''}){const u=requireUser(token);owner(db,projectId,u.id);req(Number.isFinite(amount)&&amount>0,'Recorded earnings must be positive');req(Number.isFinite(contribution)&&contribution>=0&&contribution<=amount,'Invalid voluntary contribution');
    const e={id:id('earnings'),reporterId:u.id,projectId,amount,contribution,currency:'USD',note:safeText(note,350),at:new Date().toISOString(),paymentProcessed:false};db.earnings.push(e);event(db,'earnings.self_reported',u.id,{projectId,reported:true});return clone(e);},
   suggest(token,{projectId,instruction}){const u=requireUser(token);owner(db,projectId,u.id);req(typeof instruction==='string'&&instruction.length<=1000,'Instruction invalid');
    const s=instruction.toLowerCase();const steps=[];if(/trim|clean spaces/.test(s))steps.push({op:'trim'});if(/upper|capital/i.test(s))steps.push({op:'uppercase'});else if(/lower/i.test(s))steps.push({op:'lowercase'});if(/count words|word count/.test(s))steps.push({op:'word_count'});
    return {source:'deterministic-rule-interpreter',modelLoaded:false,requiresHumanReview:true,draft:steps.length?{sourceProjectId:projectId,name:safeText(instruction,90),reason:'Draft from explicit participant instruction; review before proposing',steps}:null,message:steps.length?'Review and submit these proposed primitive steps':'Instruction stored only in your session; connect a model for broader interpretation. No changes were made.'};}
 };
}
