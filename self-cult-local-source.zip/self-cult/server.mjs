import {createServer} from 'node:http';
import {readFile, writeFile, rename, mkdir} from 'node:fs/promises';
import {resolve, join, extname, normalize, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {createEngine, createEmptyState} from './core.mjs';

const ROOT=dirname(fileURLToPath(import.meta.url));
const CONTENT_TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8'};
const LIMIT=16000;
function json(res,status,body){const b=JSON.stringify(body);res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(b);}
function fail(res,error){json(res,error?.status||400,{error:error?.message||'Unexpected error'});}
async function bodyOf(req){const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>LIMIT)throw Object.assign(new Error('Request exceeds 16 KB'),{status:413});chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}catch{throw Object.assign(new Error('Malformed JSON'),{status:400});}}
function authToken(req){return (req.headers.authorization||'').replace(/^Bearer\s+/i,'');}
export async function launch({port=Number(process.env.PORT||8787),host=process.env.HOST||'0.0.0.0',dataFile=process.env.SELF_CULT_DATA||resolve(ROOT,'data/room.json'),bootstrapKey=process.env.SELF_CULT_BOOTSTRAP_KEY||randomBytes(24).toString('base64url'),quiet=false}={}){
 let original;try{original=JSON.parse(await readFile(dataFile,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;original=createEmptyState();}
 const engine=createEngine(original);let queue=Promise.resolve();
 async function persist(){const dir=dirname(dataFile);await mkdir(dir,{recursive:true});const filename=dataFile+'.tmp';await writeFile(filename,JSON.stringify(engine.db,null,2),{mode:0o600});await rename(filename,dataFile);}
 function mutate(fn){const promise=queue.then(async()=>{const result=fn();await persist();return result;});queue=promise.catch(()=>{});return promise;}
 const server=createServer(async(req,res)=>{
  try{
   const pathname=new URL(req.url,'http://localhost').pathname;
   const origin=req.headers.origin;const origins=(process.env.SELF_CULT_ALLOWED_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
   if(origin && (origins.includes(origin)||origin===`http://${req.headers.host}`||origin===`https://${req.headers.host}`)){
     res.setHeader('access-control-allow-origin',origin);res.setHeader('vary','Origin');res.setHeader('access-control-allow-headers','authorization, content-type');res.setHeader('access-control-allow-methods','GET, POST, OPTIONS');
   }
   if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
   if(pathname.startsWith('/api/')){
    if(pathname==='/api/health'&&req.method==='GET'){json(res,200,{ready:true,initialized:engine.hasParticipants(),models:'optional; not bundled'});return;}
    const data=req.method==='POST'?await bodyOf(req):{};
    if(pathname==='/api/setup'&&req.method==='POST'){json(res,200,await mutate(()=>engine.setup({...data,expectedBootstrapKey:bootstrapKey})));return;}
    if(pathname==='/api/join'&&req.method==='POST'){json(res,200,await mutate(()=>engine.join(data)));return;}
    const token=authToken(req);if(!token){json(res,401,{error:'Participant token required'});return;}
    if(pathname==='/api/state'&&req.method==='GET'){json(res,200,engine.state(token));return;}
    const handlers={
      '/api/invite':()=>engine.invite(token),'/api/project':()=>engine.createProject(token,data),
      '/api/agent':()=>engine.setAgent(token,data),'/api/agent/suggest':()=>engine.suggest(token,data),
      '/api/proposal':()=>engine.propose(token,data),'/api/decision':()=>engine.decide(token,data),
      '/api/execute':()=>engine.execute(token,data),'/api/earnings':()=>engine.earnings(token,data),
    };
    if(req.method==='POST'&&handlers[pathname]){json(res,200,await mutate(handlers[pathname]));return;}
    json(res,404,{error:'Unknown API route'});return;
   }
   if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end();return;}
   let rel=pathname==='/'?'index.html':decodeURIComponent(pathname).slice(1);rel=normalize(rel).replace(/^([/\\])+/, '');
   const publicDir=resolve(ROOT,'public');const p=resolve(publicDir,rel);
   if(!p.startsWith(publicDir+'/')&&!p.startsWith(publicDir+'\\')){res.writeHead(403);res.end();return;}
   const bytes=await readFile(p);res.writeHead(200,{'content-type':CONTENT_TYPES[extname(p)]||'application/octet-stream','x-content-type-options':'nosniff','cache-control':'no-cache','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' https: http:; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'"});if(req.method==='HEAD')res.end();else res.end(bytes);
  }catch(e){if(e.code==='ENOENT'){res.writeHead(404);res.end('Not found');}else fail(res,e);}
 });
 await new Promise((resolveListen,reject)=>server.once('error',reject).listen(port,host,resolveListen));
 if(!quiet){console.log(`Self Cult of Agents server: http://${host}:${server.address().port}`);if(!engine.hasParticipants())console.log('ONE-TIME BOOTSTRAP KEY (keep private): '+bootstrapKey);}
 return {server,engine,port:server.address().port,bootstrapKey,close:()=>new Promise(ok=>server.close(ok))};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))launch().catch(e=>{console.error(e);process.exitCode=1});
