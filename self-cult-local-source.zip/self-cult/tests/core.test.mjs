import {test} from 'node:test';import assert from 'node:assert/strict';
import {createEngine,executeSteps,ADDRESS_FIELDS} from '../core.mjs';
test('two distinct agents, consent-gated cross-project capability and receipts',()=>{
 const e=createEngine();const a=e.setup({bootstrapKey:'secret',expectedBootstrapKey:'secret',name:'First'});const code=e.invite(a.token).code;const b=e.join({inviteCode:code,name:'Second'});
 assert.notEqual(a.participantId,b.participantId);assert.notEqual(e.state(a.token).self.agent.id,e.state(b.token).self.agent.id);
 const p1=e.createProject(a.token,{name:'Research',purpose:'Create an index',offers:'text formatting and indexing',needs:'testing'});
 const p2=e.createProject(b.token,{name:'Game',purpose:'Explore capabilities',offers:'testing',needs:'formatting'});
 assert.ok(e.state(a.token).opportunities.some(x=>x.from===p1.id&&x.to===p2.id));
 const proposal=e.propose(a.token,{sourceProjectId:p1.id,targetProjectId:p2.id,name:'Clean and capitalize',steps:[{op:'trim'},{op:'uppercase'}]});
 assert.throws(()=>e.execute(b.token,{capabilityId:'fake',projectId:p2.id,input:' x '}),/not available/);
 e.decide(a.token,{proposalId:proposal.id,decision:'approve'});assert.equal(e.state(a.token).proposals[0].status,'pending');
 e.decide(b.token,{proposalId:proposal.id,decision:'approve'});const cap=e.state(a.token).capabilities[0];
 assert.equal(e.execute(b.token,{capabilityId:cap.id,projectId:p2.id,input:' hello '}).output,'HELLO');
 assert.equal(e.state(b.token).receipts.length,1);assert.equal(e.state(a.token).receipts.length,0);
 assert.throws(()=>e.execute(a.token,{capabilityId:cap.id,projectId:p2.id,input:'x'}),/Only a project owner/);
 assert.equal(e.earnings(a.token,{projectId:p1.id,amount:30,contribution:0}).paymentProcessed,false);
 assert.equal(e.state(b.token).earnings.length,0);
 assert.ok(ADDRESS_FIELDS.join('.').includes('.arc.'));
});
test('proposed changes cannot publish without all owners, rejection and unsafe operations blocked',()=>{
 const e=createEngine();const a=e.setup({bootstrapKey:'x',expectedBootstrapKey:'x',name:'A'});const b=e.join({inviteCode:e.invite(a.token).code,name:'B'});
 const p=e.createProject(a.token,{name:'A'}),q=e.createProject(b.token,{name:'B'});
 assert.throws(()=>e.propose(a.token,{sourceProjectId:p.id,targetProjectId:q.id,name:'unsafe',steps:[{op:'eval',source:'process.exit()'}]}),/Unknown approved primitive/);
 const x=e.propose(a.token,{sourceProjectId:p.id,targetProjectId:q.id,name:'safe',steps:[{op:'lowercase'}]});
 assert.throws(()=>e.decide(a.token,{proposalId:x.id,decision:'wrong'}),/Decision/);
 e.decide(b.token,{proposalId:x.id,decision:'reject'});assert.equal(e.state(a.token).proposals[0].status,'rejected');assert.equal(e.state(a.token).capabilities.length,0);
 assert.throws(()=>e.createProject(a.token,{name:'invalid address',address:{gate:6}}),/13 ontological/);
 assert.throws(()=>executeSteps('x',[{op:'replace_all',search:'',replacement:'X'}]),/Invalid replacement/);
});
