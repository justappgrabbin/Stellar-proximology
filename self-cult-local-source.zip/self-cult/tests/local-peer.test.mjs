import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const E = await import('../android/assets/engine.js').then(()=>globalThis.SelfCultEngine);
const event=(actor,type,data,n)=>({id:`${actor}:${String(n).padStart(6,'0')}`,actor,type,at:1700000000000+n,data});
const a='person_a',b='person_b',c='person_mallory';
const base=[event(a,'participant',{name:'A'},1),event(b,'participant',{name:'B'},2),event(a,'project',{id:'A',ownerId:a,name:'Documentation',purpose:'Share writing',offers:'editing research',needs:'prototype'},3),event(b,'project',{id:'B',ownerId:b,name:'Prototype',purpose:'build',offers:'prototype',needs:'editing'},4)];
test('standalone local replay works offline with original thirteen address fields',()=>{
 const db=E.replay(base);
 assert.equal(db.projects.length,2);
 assert.equal(db.opportunities.length,2);
 assert.equal(E.ADDRESS_FIELDS.join('.'),'planetary.dimension.gate.line.color.tone.base.degree.minute.second.arc.zodiac.house');
 assert.equal(E.execute('   shared possibilities  ',[{op:'trim'},{op:'uppercase'}]).output,'SHARED POSSIBILITIES');
});
test('cross-project capability is rejected until the other owner approves',()=>{
 const steps=[{op:'trim'},{op:'uppercase'}];
 const p=event(a,'proposal',{id:'p1',sourceProjectId:'A',targetProjectId:'B',name:'Format',steps},5);
 const approvalA=event(a,'decision',{proposalId:'p1',decision:'approve'},6);
 const fakeApproval=event(c,'decision',{proposalId:'p1',decision:'approve'},7);
 assert.equal(E.replay([...base,p,approvalA,fakeApproval]).capabilities.length,0);
 const approvalB=event(b,'decision',{proposalId:'p1',decision:'approve'},8);
 const d=E.replay([...base,p,approvalA,fakeApproval,approvalB]);
 assert.equal(d.capabilities.length,1);
 assert.deepEqual(d.capabilities[0].availableTo,['A','B']);
 assert.equal(E.execute('  network ',d.capabilities[0].steps).output,'NETWORK');
});
test('local execution observation affects relation but unverified does not',()=>{
 const obs1=event(b,'observation',{a:'A',b:'B',outcome:0.8,verified:true},9);
 const obs2=event(b,'observation',{a:'A',b:'B',outcome:-1,verified:false},10);
 const d=E.replay([...base,obs1,obs2]);
 assert.equal(d.edges.length,1);assert.equal(d.edges[0].observations,1);
 assert.ok(Math.abs(d.edges[0].weight-0.12)<1e-9);
});
test('Android entry is packaged, local and does not need hosted HTTPS',()=>{
 const java=readFileSync(new URL('../android/src/org/selfcult/agents/MainActivity.java',import.meta.url),'utf8');
 const html=readFileSync(new URL('../android/assets/index.html',import.meta.url),'utf8');
 assert.match(java,/loadUrl\("file:\/\/\/android_asset\/index.html"\)/);
 assert.match(java,/AES\/GCM\/NoPadding/);
 assert.match(java,/ServerSocket\(PORT\)/);
 assert.doesNotMatch(java,/https:\/\//);
 assert.doesNotMatch(html,/<script[^>]+https?:\/\//);
});
