import {test} from 'node:test';import assert from 'node:assert/strict';
import {launch} from '../server.mjs';import {mkdtemp,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import {join} from 'node:path';
test('HTTP collaboration works for two real sessions, persists and requires approval',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'selfcult-'));const api=await launch({port:0,host:'127.0.0.1',dataFile:join(dir,'room.json'),bootstrapKey:'secret',quiet:true});
 const base=`http://127.0.0.1:${api.port}`;const post=async(p,b,t)=>{const r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json',...(t?{authorization:'Bearer '+t}:{})},body:JSON.stringify(b)});return {status:r.status,body:await r.json()};};
 const get=async(p,t)=>{const r=await fetch(base+p,{headers:t?{authorization:'Bearer '+t}:{}});return {status:r.status,body:await r.json()};};
 try{
  assert.equal((await get('/api/health')).body.initialized,false);
  const a=(await post('/api/setup',{bootstrapKey:'secret',name:'First'})).body;
  const inv=(await post('/api/invite',{},a.token)).body.code;
  const b=(await post('/api/join',{inviteCode:inv,name:'Second'})).body;
  assert.equal((await post('/api/join',{inviteCode:inv,name:'Intruder'})).status,400);
  const proj=(await post('/api/project',{name:'Project A',offers:'writing'},a.token)).body;
  const projB=(await post('/api/project',{name:'Project B',needs:'writing'},b.token)).body;
  const c=(await post('/api/proposal',{sourceProjectId:proj.id,targetProjectId:projB.id,name:'Upcase',steps:[{op:'uppercase'}]},a.token)).body;
  await post('/api/decision',{proposalId:c.id,decision:'approve'},a.token);
  assert.equal((await get('/api/state',a.token)).body.capabilities.length,0);
  await post('/api/decision',{proposalId:c.id,decision:'approve'},b.token);
  const cap=(await get('/api/state',b.token)).body.capabilities[0];
  assert.equal((await post('/api/execute',{capabilityId:cap.id,projectId:projB.id,input:'hello'},b.token)).body.output,'HELLO');
  assert.equal((await get('/api/state','wrong')).status,401);
  {const page=await fetch(base+'/');assert.equal(page.status,200);assert.match(await page.text(),/Self Cult/);}
  const e=(await post('/api/earnings',{projectId:proj.id,amount:10,contribution:0},a.token)).body;assert.equal(e.paymentProcessed,false);
 }finally{await api.close();await rm(dir,{recursive:true,force:true});}
});
