# The Self Cult of Agents — Local-First Android v0.2

**START HERE:** The current local-first Android APK works without a website, an external server, or login. Open the app to create projects and run limited approved text capabilities offline. For two-device collaboration, leave the app open on both devices connected to the same Wi-Fi/hotspot; one device shares an SC1 invitation, the other pastes it under **Connect** and initiates encrypted synchronization.

See [ANDROID_LOCAL_FIRST.md](ANDROID_LOCAL_FIRST.md) for exact steps, boundaries, and limitations. Application id `org.selfcult.agents.local`; may coexist with the earlier hosted launcher.

This is an **additive bounded experiment**, not a replacement for the full Synthia StateSpace, Klein, ATO, Tool Factory, or the entire Resonance Network. Shared data remains device-local unless explicitly synchronized with a paired peer. Private model instructions and voluntary contribution records are not exchanged. TinyLlama and Qwen selections are preferences; language models are **not bundled or executing** yet.

The earlier experimental Node.js website/server implementation is preserved below as an OPTIONAL historical pilot; it is **not used by the local APK**.

---

# The Self Cult of Agents — first bounded relational experiment

**Name:** The Self Cult of Agents is a play on *cultivation of self*, not a literal cult.

**Purpose:** Discover connections that money cannot buy and opportunities that would not otherwise exist. No joining fee. No automatic fee or revenue deduction. Recorded earnings and potential contributions are voluntary and private.

## What works now

- Two distinct participant sessions on two devices connected to the same Node.js server.
- One-time invite codes, individual agent contexts and explicit model **preferences** (Qwen3 0.6B or TinyLlama 1.1B).
- Projects with declared offers and needs; transparent opportunity matching without invented scores.
- Approved primitive composition and executable text tools; **both project owners** must approve cross-project access.
- Actual cross-project execution receipts, replayable event history, and the original Pure Synthia `ResonanceNetwork` relation update on **verified executions**.
- Voluntary earnings and contribution *records*, **no payments collected**.
- Mobile-first browser interface. Minimal Android WebView client built through GitHub Actions; it requires the deployed HTTPS server URL.

The built-in `agent/suggest` endpoint is explicitly a deterministic rule interpreter. **No LLM runs or downloads in this release.** Model selections are preferences for later integration with actual model runtimes. No self-modification or autonomous deployment is enabled. The implementation does not claim to be the complete existing Synthia StateSpace, FocalStateSpace, ATO, Tool Factory or Klein runtime.

## Run the website and shared server

```bash
cd self-cult
export SELF_CULT_BOOTSTRAP_KEY='choose-a-private-long-secret'
npm test
npm start
```

Open the displayed address in a browser. Choose **I'm creating the first space** and use your private bootstrap key. Create an invitation for the second person and give it to them privately. Both devices must connect to **the same publicly reachable HTTPS server** (or a local server on the same trusted network).

The server stores its state in `self-cult/data/room.json` by default. For hosted deployment, set `SELF_CULT_DATA` to a **persistent volume path** and `SELF_CULT_ALLOWED_ORIGINS` to the exact browser origin if using a separate static host. Without durable storage, a container restart may reset the room.

### Android build

GitHub Actions runs `.github/workflows/self-cult-android.yml`. The artifact is an unsigned-in-the-source but development-signed Android APK; it does **not** replace or alter your existing Stellar APK. First launch asks for the HTTPS address of the hosted Self Cult web application. On GitHub Actions, open the latest Android workflow run and obtain `Self-Cult-of-Agents-APK` from Artifacts.

GitHub Pages can host a static *front end*, but a static site alone cannot persist cross-device room state. Do not mistake a Pages preview for a deployed live network. The application can be served directly by Node.js without additional UI hosting.

## First experiment

1. Participant A creates a project offering a capability.
2. Participant B creates a project needing that capability.
3. The system records a potential connection, grounded in overlapping declared words.
4. A proposes a bounded executable sequence such as `trim` → `uppercase`.
5. A approves the proposal; it stays pending.
6. B approves it; publication makes the actual composed capability available to both projects.
7. B executes it and receives a result, trace, and durable receipt. The existing Resonance Network donor records the verified cross-project interaction.

No completed capability is automatically written by an LLM. Primitive composition is currently deliberately small and inspectable.

## Ontology and source provenance

The exact external ontology remains `planetary.dimension.gate.line.color.tone.base.degree.minute.second.arc.zodiac.house` (13 fields). `arc` is not silently renamed to `arcAxis`. Unknown positions remain unresolved, never keyword-guessed. Gate and HEXAGRAM are not conflated.

`donors/resonance-network.mjs` is copied unmodified from the user-supplied `stellar-adaptive-seed-final.zip` → `dist/Stellar-Proximology-source.zip` → `assets/web/lab/pure-synthia/engine/resonance-network.js` (ported from Synthia-OS-v2.0.0-COHERENT). It is used for observed relation updates. Other original archives and projects remain untouched.

This bounded relational prototype is an *additive pilot*, not a replacement for the full existing StateSpace, Klein, Tool Factory and ATO engines. Its intentionally restricted primitive set must not be called a fully autonomous self-building system.

## Security and limitations

Development pilot, not production-hardened. Use HTTPS, keep bootstrap and session tokens private, use a trusted host, and back up the server's persistent data file. Project needs and offers are visible to participants. No real-money processing. Do not put API keys, medical data or private secrets into project fields. The server does not provide real-time push; refresh the browser to see new remote changes. Android APK is development-signed with a new key each CI run (reinstallation may be required).

## v0.2 local-first Android variant (separate from v0.1 hosted website)

**The Android APK now packages its own HTML/CSS/JavaScript and does not ask for an external server.** It keeps private device state, local projects, primitive execution, optional contribution intentions, individual instructions, and a paired peer event log. Its embedded direct-LAN listener runs only while the app is foregrounded. The older standalone Node website remains in `public/` / `server.mjs` for source provenance; the Android APK does **not** load it, require it, or connect to it.

Two phones can exchange events directly on the **same Wi-Fi or hotspot**. On phone A, open **Connect**, share the 32-digit pairing key and local IP. On phone B, open **Connect**, enter phone A's key and IP, then **Pair / Sync now**. Both apps must be open. B sends its own events and receives A's own events, encrypted with AES-GCM. Later interactions are synced manually, and A may also enter B's IP to initiate synchronization. No internet connection is required after downloading the APK.

A cross-project capability is not published until both project owners explicitly approve, and actual primitive execution is performed on-device. Models are only preferences and are not bundled. There is no autonomous code generation or canonical ontological resolver yet. This is a bounded two-person direct-LAN pilot, **not** an internet-wide decentralized mesh; it has manual discovery, no background processing, no relays, no cross-NAT connections, no independent event signatures, and has not been installed on physical phones in this environment. The pairing key is a shared secret and must be treated as private; this is a research pilot, not a production hardened messenger. The build's development key changes between CI runs, so installing as an update over a previous development build may require removing the old APK first, losing its in-app data. Back up any real data before reinstalling.

The archive also includes the original `donors/resonance-network.mjs` and all the original Node-side functionality. The Android client uses a separate compact JS replay implementation for the same **bounded relational observation update**, with provenance retained, rather than claiming every Synthia subsystem has been ported to Android.
