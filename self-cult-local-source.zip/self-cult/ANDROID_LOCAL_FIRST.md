# Self Cult of Agents — local-first Android v0.2

## This is a separate install, not a URL launcher

Android application id: `org.selfcult.agents.local`, separate from earlier `org.selfcult.agents` so an Android device can install both despite development signature changes. Native WebView loads `file:///android_asset/index.html`, with bundled HTML/CSS/JS. There is no remote API or website dependency. Data is stored locally in Android SharedPreferences and private WebView localStorage. Android Java serves encrypted LAN packets through an explicitly paired peer listener on port 47773 while the app is visible. No external central server.

## Use two phones

1. Install on both Android phones; each makes a local profile and project.
2. Connect both to the same Wi-Fi or mobile hotspot, leave the apps visible.
3. Phone A: open **Connect**, send its full SC1 invitation privately to phone B using the Share button.
4. Phone B: open **Connect**, paste A's complete SC1 invitation and tap **Pair and sync directly**. The phones exchange their own event logs directly.
5. After either phone creates new projects/proposals or approvals, manually **Sync** again; direct remote events are merged and replayed. Proposals must be explicitly approved by both project owners before a shared executable text capability is available.
6. Each phone keeps its state and tools after disconnection. Optional private earnings/contributions and model preferences are not synchronized. No payment processing.

## Boundaries

- One peer; no discovery service, background daemon, TURN, relay, cloud persistence or internet-wide peer routing. Network AP/client isolation may block even same-Wi-Fi connections. Firewall/hotspot settings vary.
- AES-GCM packets with random shared 128-bit pairing secret; key possession authenticates the peer during exchange. This is not independently signed per-event or a production messenger; keep the shared key private.
- Peer events are bounded and replay validates known operations and owner decisions. Owner identity is verified against the recorded event's author *within the shared-secret trust model*. This is not a cryptographic per-human signature.
- Java listener does not stay active if the Activity is backgrounded. Both devices must be awake with the app visible for a sync.
- No Qwen/TinyLlama binary or inference engine bundled. Preferences are not proof of model execution.
- The example primitives are actual restricted text transformations, not the full Synthia ontological compiler, Klein engine, ATO or Tool Factory. Canonical address remains 13 fields with unresolved values.
- No real Android phones were available in the build environment. CI compilation and Node unit tests do not replace two-phone pairing tests.


## Security and persistence notes (v0.2)

- Native AES-GCM protects LAN messages between explicitly paired phones. The pairing key is a shared secret: revealing it allows impersonation. No remote relay is provided.
- The recipient checks the peer's locally bound identity; history is signed only by possession of the pair key, not by independently verified per-participant keypairs.
- Contributions and local agent instructions are deliberately excluded from peer sync. Offers, needs, approved proposals and execution receipts are shared with the one paired peer.
- The state log keeps the most recent 300 events; this is a bounded pilot, **not** permanent archival storage or full autonomous StateSpace.
- The APK uses a different package name (`org.selfcult.agents.local`) so it can coexist with the earlier server-dependent launcher.
