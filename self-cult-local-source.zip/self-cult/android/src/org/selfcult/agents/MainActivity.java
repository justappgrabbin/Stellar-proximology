package org.selfcult.agents;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import android.util.Base64;

/** Local-first Android peer. No hosted URL, cloud API or bundled language model.
 * Every device is autonomous and synchronizes ONLY with an explicitly paired device over the LAN.
 * The local socket listener runs while this Activity is visible; no background server.
 */
public final class MainActivity extends Activity {
  private static final int PORT=47773;
  private static final int MAX_EVENTS=300;
  private static final int MAX_LINE=2500000;
  private static final String[] TYPES={"participant","project","proposal","decision","observation","receipt","contribution"};
  private final Object lock=new Object();
  private final SecureRandom random=new SecureRandom();
  private SharedPreferences prefs;
  private WebView web;
  private ServerSocket listener;
  private volatile boolean listening=false;
  private Thread acceptThread;
  private final Handler mainHandler=new Handler(Looper.getMainLooper());

  @Override public void onCreate(Bundle b){super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(25,11,31));getWindow().setNavigationBarColor(Color.rgb(25,11,31));
    prefs=getSharedPreferences("selfcult_local_v2",MODE_PRIVATE);
    if(!prefs.contains("device_id"))prefs.edit().putString("device_id","person_"+UUID.randomUUID().toString().replace("-","")).apply();
    if(!prefs.contains("pair_key")){byte[] bytes=new byte[16];random.nextBytes(bytes);prefs.edit().putString("pair_key",hex(bytes)).apply();}
    web=new WebView(this);web.setBackgroundColor(Color.rgb(25,11,31));
    web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);
    web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
    web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.addJavascriptInterface(new Bridge(),"Native");
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){return !isBundled(req.getUrl().toString());}
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){return isBundled(req.getUrl().toString())?null:new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));}
    });
    setContentView(web);web.loadUrl("file:///android_asset/index.html");
  }
  private static boolean isBundled(String url){return url.startsWith("file:///android_asset/")&&!url.contains("..")&&!url.contains("?");}
  @Override protected void onResume(){super.onResume();startListener();}
  @Override protected void onPause(){stopListener();super.onPause();}
  @Override protected void onDestroy(){stopListener();if(web!=null){web.destroy();web=null;}super.onDestroy();}
  private String ownId(){return prefs.getString("device_id","");}
  private String ownName(){return prefs.getString("nickname","Participant");}
  private static String hex(byte[] x){StringBuilder b=new StringBuilder();for(byte a:x)b.append(String.format(java.util.Locale.US,"%02x",a&255));return b.toString();}
  private String ip(){try{Enumeration<NetworkInterface> nets=NetworkInterface.getNetworkInterfaces();while(nets.hasMoreElements()){
    NetworkInterface n=nets.nextElement();if(!n.isUp()||n.isLoopback())continue;
    Enumeration<InetAddress> addrs=n.getInetAddresses();while(addrs.hasMoreElements()){
      InetAddress a=addrs.nextElement();if(a instanceof Inet4Address&&a.isSiteLocalAddress())return a.getHostAddress();
    }
  }}catch(Exception ignored){}return "Not on local Wi-Fi / hotspot";}
  private static boolean validLocalIp(String value){try{
    if(value==null||!value.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}"))return false;
    String[] parts=value.split("\\.");for(String p:parts)if(Integer.parseInt(p)>255)return false;
    InetAddress a=InetAddress.getByName(value);return a instanceof Inet4Address&&a.isSiteLocalAddress();
  }catch(Exception e){return false;}}
  private static boolean allowedType(String type){for(String x:TYPES)if(x.equals(type))return true;return false;}
  private JSONArray events(){try{return new JSONArray(prefs.getString("events","[]"));}catch(Exception e){return new JSONArray();}}
  private JSONArray ownEvents(){JSONArray out=new JSONArray(),all=events();for(int i=0;i<all.length();i++){JSONObject e=all.optJSONObject(i);if(e!=null&&ownId().equals(e.optString("actor"))&&!"contribution".equals(e.optString("type")))out.put(e);}return out;}
  private int merge(JSONArray input,String peerId){synchronized(lock){
    JSONArray old=events();HashSet<String> ids=new HashSet<>();for(int i=0;i<old.length();i++){JSONObject item=old.optJSONObject(i);if(item!=null)ids.add(item.optString("id"));}
    int count=0;for(int i=0;i<input.length()&&i<MAX_EVENTS;i++){
      JSONObject e=input.optJSONObject(i);if(e==null)continue;
      String eid=e.optString("id"),actor=e.optString("actor"),type=e.optString("type");
      if(!actor.equals(peerId)||!eid.startsWith(actor+":")||eid.length()>110||ids.contains(eid)||!allowedType(type)||"contribution".equals(type))continue;
      JSONObject data=e.optJSONObject("data");if(data==null||data.toString().length()>4000||e.optLong("at",0L)<=0)continue;
      old.put(e);ids.add(eid);count++;
    }
    if(old.length()>MAX_EVENTS){JSONArray limited=new JSONArray();for(int i=old.length()-MAX_EVENTS;i<old.length();i++)limited.put(old.opt(i));old=limited;}
    if(count>0)prefs.edit().putString("events",old.toString()).apply();return count;
  }}
  private String appendLocal(String type,String dataRaw){synchronized(lock){try{
    if(!allowedType(type)||dataRaw==null||dataRaw.length()>4000)throw new IllegalArgumentException("Invalid local event");
    JSONObject data=new JSONObject(dataRaw),e=new JSONObject();
    e.put("id",ownId()+":"+UUID.randomUUID().toString());e.put("actor",ownId());e.put("type",type);e.put("at",System.currentTimeMillis());e.put("data",data);
    JSONArray old=events();old.put(e);if(old.length()>MAX_EVENTS){JSONArray l=new JSONArray();for(int i=old.length()-MAX_EVENTS;i<old.length();i++)l.put(old.opt(i));old=l;}
    prefs.edit().putString("events",old.toString()).apply();return e.toString();
  }catch(Exception ex){return new JSONObject().toString();}}}
  private SecretKeySpec pairKey()throws Exception{String secret=prefs.getString("pair_key","");byte[] bytes=MessageDigest.getInstance("SHA-256").digest(secret.getBytes(StandardCharsets.UTF_8));return new SecretKeySpec(bytes,"AES");}
  private String seal(String plaintext)throws Exception{
    byte[] nonce=new byte[12];random.nextBytes(nonce);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,pairKey(),new GCMParameterSpec(128,nonce));byte[] ct=c.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));byte[] all=new byte[nonce.length+ct.length];System.arraycopy(nonce,0,all,0,12);System.arraycopy(ct,0,all,12,ct.length);return Base64.encodeToString(all,Base64.NO_WRAP);
  }
  private String open(String message)throws Exception{
    byte[] all=Base64.decode(message,Base64.NO_WRAP);if(all.length<29)throw new IllegalArgumentException("Invalid packet");
    byte[] iv=new byte[12],cipher=new byte[all.length-12];System.arraycopy(all,0,iv,0,12);System.arraycopy(all,12,cipher,0,cipher.length);
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,pairKey(),new GCMParameterSpec(128,iv));return new String(c.doFinal(cipher),StandardCharsets.UTF_8);
  }
  private String readBounded(BufferedReader r)throws Exception{StringBuilder b=new StringBuilder();int c;while((c=r.read())!=-1&&c!='\n'){b.append((char)c);if(b.length()>MAX_LINE)throw new IllegalArgumentException("Message exceeds limit");}if(b.length()==0)throw new IllegalArgumentException("No packet");return b.toString();}
  private JSONObject outbound()throws Exception{JSONObject message=new JSONObject();message.put("deviceId",ownId());message.put("name",ownName());message.put("events",ownEvents());return message;}
  private void verifyPeer(String id)throws Exception{if(id.length()<10||id.length()>100||id.equals(ownId()))throw new IllegalArgumentException("Invalid peer identity");synchronized(lock){String known=prefs.getString("peer_id","");if(!known.isEmpty()&&!known.equals(id))throw new SecurityException("Different paired peer");if(known.isEmpty())prefs.edit().putString("peer_id",id).apply();}}
  private void serve(Socket socket){try(Socket s=socket){s.setSoTimeout(7000);
    BufferedReader input=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));BufferedWriter output=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8));
    JSONObject request=new JSONObject(open(readBounded(input))),response=outbound();String peer=request.optString("deviceId");verifyPeer(peer);
    prefs.edit().putString("peer_ip",s.getInetAddress().getHostAddress()).putString("peer_name",request.optString("name","Peer")).apply();
    int added=merge(request.optJSONArray("events")!=null?request.getJSONArray("events"):new JSONArray(),peer);
    output.write(seal(response.toString()));output.write('\n');output.flush();
    if(added>0)inform("peerUpdated",(JSONObject)null);
  }catch(Exception ignored){ /* bad packet or unauthenticated peer: no response */ }}
  private synchronized void startListener(){if(listening)return;try{
    listener=new ServerSocket(PORT);listener.setReuseAddress(true);listener.setSoTimeout(1200);listening=true;
    acceptThread=new Thread(()->{while(listening){try{Socket s=listener.accept();serve(s);}catch(SocketTimeoutException ignored){}catch(Exception e){if(!listening)break;}}},"selfcult-lan-listener");acceptThread.setDaemon(true);acceptThread.start();
  }catch(Exception ex){inform("listenerError",ex.getMessage());}}
  private synchronized void stopListener(){listening=false;try{if(listener!=null)listener.close();}catch(Exception ignored){}listener=null;}
  private void inform(String function,JSONObject detail){mainHandler.post(()->{if(web!=null){String json=detail==null?"null":detail.toString();web.evaluateJavascript("window."+function+" && window."+function+"("+json+");",null);}});}
  private void inform(String function,String message){mainHandler.post(()->{if(web!=null)web.evaluateJavascript("window."+function+" && window."+function+"("+JSONObject.quote(message==null?"":message)+");",null);});}
  private void syncPeer(String host){JSONObject result=new JSONObject();try{
    if(!validLocalIp(host))throw new IllegalArgumentException("Use a private local IPv4 address on the same Wi-Fi or hotspot");
    try(Socket s=new Socket()){s.connect(new java.net.InetSocketAddress(host,PORT),6500);s.setSoTimeout(9000);
      BufferedWriter o=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8));BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));
      o.write(seal(outbound().toString()));o.write('\n');o.flush();JSONObject reply=new JSONObject(open(readBounded(in)));String peer=reply.optString("deviceId");verifyPeer(peer);
      int added=merge(reply.optJSONArray("events")!=null?reply.getJSONArray("events"):new JSONArray(),peer);
      prefs.edit().putString("peer_ip",host).putString("peer_name",reply.optString("name","Peer")).apply();result.put("ok",true);result.put("received",added);result.put("peerName",reply.optString("name"));
    }
  }catch(Exception e){try{result.put("ok",false);result.put("error","Could not securely sync. Check same network, shared pairing key, and that both apps are open. "+String.valueOf(e.getMessage()).replaceAll("[\\r\\n]"," "));}catch(Exception ignored){}}
    inform("syncResult",result);
  }
  public final class Bridge {
    @JavascriptInterface public String state(){synchronized(lock){try{
      JSONObject x=new JSONObject();x.put("id",ownId());x.put("name",ownName());x.put("ip",ip());x.put("port",PORT);x.put("key",prefs.getString("pair_key",""));x.put("peerId",prefs.getString("peer_id",""));x.put("peerIp",prefs.getString("peer_ip",""));x.put("peerName",prefs.getString("peer_name",""));x.put("model",prefs.getString("model","none"));x.put("instructions",prefs.getString("instructions",""));x.put("listener",listening);x.put("events",events());return x.toString();
    }catch(Exception e){return "{}";}}}
    @JavascriptInterface public String record(String type,String data){return appendLocal(type,data);}
    @JavascriptInterface public void name(String x){String value=x==null?"":x.trim();if(value.isEmpty()||value.length()>65)return;prefs.edit().putString("nickname",value).apply();}
    @JavascriptInterface public boolean setKey(String key){if(key==null||!key.matches("[0-9a-fA-F]{32}"))return false;
      prefs.edit().putString("pair_key",key.toLowerCase(java.util.Locale.US)).remove("peer_id").remove("peer_name").apply();return true;}
    @JavascriptInterface public void setAgent(String model,String instructions){if(model==null||!(model.equals("none")||model.equals("qwen")||model.equals("tinyllama")))return;if(instructions==null||instructions.length()>1500)return;prefs.edit().putString("model",model).putString("instructions",instructions).apply();}
    @JavascriptInterface public void sync(String host){new Thread(()->syncPeer(host),"selfcult-lan-sync").start();}
    @JavascriptInterface public void copy(String text){mainHandler.post(()->{ClipboardManager m=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);m.setPrimaryClip(ClipData.newPlainText("Self Cult peer pairing",text));});}
    @JavascriptInterface public void share(String text){mainHandler.post(()->{android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(android.content.Intent.EXTRA_TEXT,text);startActivity(android.content.Intent.createChooser(i,"Share peer invitation"));});}
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
