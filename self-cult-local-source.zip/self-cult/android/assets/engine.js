/* Self Cult v0.2 — bounded local replay engine. No remote API or LLM. */
(function(global){
 'use strict';
 const ADDRESS_FIELDS=['planetary','dimension','gate','line','color','tone','base','degree','minute','second','arc','zodiac','house'];
 const OPS=['trim','uppercase','lowercase','prefix','suffix','replace_all','slice','word_count'];
 const txt=(x,max=6000)=>String(x??'').slice(0,max);
 function validSteps(steps){
   if(!Array.isArray(steps)||!steps.length||steps.length>6)throw Error('Use 1–6 approved primitives');
   return steps.map(s=>{if(!s||!OPS.includes(s.op))throw Error('Unapproved operation');const r={op:s.op};
    if(s.op==='prefix'||s.op==='suffix'){if(typeof s.text!=='string'||s.text.length>200)throw Error('Invalid text parameter');r.text=s.text;}
    if(s.op==='replace_all'){if(!s.search||typeof s.search!=='string'||s.search.length>100||typeof s.replacement!=='string'||s.replacement.length>200)throw Error('Invalid replacement');r.search=s.search;r.replacement=s.replacement;}
    if(s.op==='slice'){if(!Number.isInteger(s.start)||!Number.isInteger(s.end)||s.start<0||s.end<s.start||s.end>6000)throw Error('Invalid slice');r.start=s.start;r.end=s.end;}
    return r;
   });
 }
 function execute(input,steps){let value=txt(input);let trace=[];for(const s of validSteps(steps)){
  switch(s.op){case'trim':value=value.trim();break;case'uppercase':value=value.toUpperCase();break;case'lowercase':value=value.toLowerCase();break;case'prefix':value=s.text+value;break;case'suffix':value=value+s.text;break;case'replace_all':value=value.split(s.search).join(s.replacement);break;case'slice':value=value.slice(s.start,s.end);break;case'word_count':value=String((value.trim().match(/\S+/g)||[]).length);break;}
  if(value.length>6000)throw Error('Output outside bounded region');trace.push({primitive:s.op,length:value.length});
 }return{output:value,trace};}
 const tokens=s=>[...new Set(txt(s).toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>2))];
 function replay(events){
  let ordered=(events||[]).filter(e=>e&&typeof e==='object'&&typeof e.id==='string'&&typeof e.actor==='string').sort((a,b)=>(a.at-b.at)||a.id.localeCompare(b.id));
  let users=new Map(),projects=new Map(),proposals=new Map(),observations=[],earnings=[],receipts=[];
  for(const e of ordered){const d=e.data||{};
   if(e.type==='participant'&&typeof d.name==='string')users.set(e.actor,{id:e.actor,name:txt(d.name,65),model:['qwen','tinyllama','none'].includes(d.model)?d.model:'none'});
   if(e.type==='project'&&d.id&&d.ownerId===e.actor&&!projects.has(d.id)&&typeof d.name==='string')projects.set(d.id,{id:txt(d.id,100),ownerId:e.actor,name:txt(d.name,100),purpose:txt(d.purpose,1000),offers:txt(d.offers,350),needs:txt(d.needs,350),address:null});
  }
  for(const e of ordered){let d=e.data||{};
   if(e.type==='proposal'&&d.id&&!proposals.has(d.id)&&typeof d.name==='string'){
    const source=projects.get(d.sourceProjectId),target=d.targetProjectId?projects.get(d.targetProjectId):null;
    if(!source||source.ownerId!==e.actor||(d.targetProjectId&&!target))continue;
    try{const steps=validSteps(d.steps);proposals.set(d.id,{id:d.id,name:txt(d.name,100),reason:txt(d.reason,700),sourceProjectId:source.id,targetProjectId:target?.id||null,authorId:e.actor,steps,approvals:[],status:'pending'});}catch(_){ }
   }
  }
  for(const e of ordered){const d=e.data||{};
   if(e.type==='decision'&&typeof d.proposalId==='string'){
    const p=proposals.get(d.proposalId);if(!p||p.status!=='pending')continue;
    const a=projects.get(p.sourceProjectId)?.ownerId,b=p.targetProjectId?projects.get(p.targetProjectId)?.ownerId:null;
    if(e.actor!==a&&e.actor!==b)continue;
    if(d.decision==='reject'){p.status='rejected';continue;}
    if(d.decision==='approve'&&!p.approvals.includes(e.actor))p.approvals.push(e.actor);
    if([a,b].filter(Boolean).every(x=>p.approvals.includes(x)))p.status='published';
   }
   if(e.type==='observation'&&typeof d.a==='string'&&typeof d.b==='string'&&d.a!==d.b&&Number.isFinite(d.outcome))observations.push({a:d.a,b:d.b,outcome:Math.max(-1,Math.min(1,d.outcome)),verified:d.verified===true,actor:e.actor});
  }
  const caps=[...proposals.values()].filter(p=>p.status==='published').map(p=>({id:'cap_'+p.id,name:p.name,steps:p.steps,ownerProjectId:p.sourceProjectId,availableTo:[p.sourceProjectId,...(p.targetProjectId?[p.targetProjectId]:[])],approvedBy:[...p.approvals]}));
  for(const e of ordered){const d=e.data||{};if(e.type==='receipt'&&d.ownerId===e.actor)receipts.push(d);if(e.type==='contribution'&&d.ownerId===e.actor)earnings.push(d);}
  const matches=[];const all=[...projects.values()];for(const a of all)for(const b of all){if(a.ownerId===b.ownerId)continue;const intersection=tokens(a.offers).filter(x=>tokens(b.needs).includes(x));if(intersection.length)matches.push({a:a.id,b:b.id,terms:intersection});}
  const edges=new Map();for(const o of observations){const id=[o.a,o.b].sort().join(' <-> ');let edge=edges.get(id)||{id,a:o.a,b:o.b,weight:0,observations:0};if(o.verified){edge.weight=0.85*edge.weight+0.15*o.outcome;edge.observations++;}edges.set(id,edge);}
  return{users:[...users.values()],projects:all,proposals:[...proposals.values()],capabilities:caps,opportunities:matches,observations,edges:[...edges.values()],earnings,receipts,events:ordered};
 }
 global.SelfCultEngine={ADDRESS_FIELDS,OPS,validSteps,execute,replay};
})(globalThis);
