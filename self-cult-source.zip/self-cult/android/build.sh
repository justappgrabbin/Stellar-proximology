#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -d "$SDK/platforms/android-35" ] || { echo 'Android SDK 35 missing'; exit 1; }
B="$SDK/build-tools/35.0.0"
[ -x "$B/aapt2" ] || { echo 'Build Tools 35.0.0 missing'; exit 1; }
rm -rf build/android
mkdir -p build/android/classes build/android/dex dist
javac -source 8 -target 8 -cp "$SDK/platforms/android-35/android.jar" -d build/android/classes android/src/org/selfcult/agents/MainActivity.java
"$B/d8" --min-api 26 --output build/android/dex $(find build/android/classes -name '*.class')
"$B/aapt2" link -o build/android/unsigned.apk --manifest android/AndroidManifest.xml -I "$SDK/platforms/android-35/android.jar" --min-sdk-version 26 --target-sdk-version 35
(cd build/android/dex && zip -q -r ../unsigned.apk classes.dex)
"$B/zipalign" -f -p 4 build/android/unsigned.apk build/android/aligned.apk
# Development signature only: generated per CI run; replace with a persistent private signing key for upgrades.
keytool -genkeypair -alias selfcult -keyalg RSA -keysize 2048 -validity 30 -keystore build/android/debug.jks -storepass android -keypass android -dname 'CN=Self Cult development build,O=Synthia' -noprompt >/dev/null 2>&1
"$B/apksigner" sign --ks build/android/debug.jks --ks-key-alias selfcult --ks-pass pass:android --key-pass pass:android --out dist/Self-Cult-of-Agents.apk build/android/aligned.apk
"$B/apksigner" verify --verbose dist/Self-Cult-of-Agents.apk
ls -lh dist/Self-Cult-of-Agents.apk
