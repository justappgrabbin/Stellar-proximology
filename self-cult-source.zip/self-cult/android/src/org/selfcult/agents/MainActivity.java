package org.selfcult.agents;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputType;
import android.net.Uri;

/** Minimal native Android entry to the same verified two-person web application.
 *  Does not claim offline inference or native integration with the existing Stellar APK.
 */
public class MainActivity extends Activity {
  private WebView web;
  private SharedPreferences prefs;
  private String allowedOrigin;
  private final int bg = Color.rgb(25,11,31);
  private final int fg = Color.rgb(250,234,250);
  @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);prefs=getSharedPreferences("self_cult",MODE_PRIVATE);String url=prefs.getString("room_url","");if(url.length()>0)openRoom(url);else showSetup();}
  private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(fg);t.setPadding(0,8,0,8);return t;}
  private void showSetup(){
    if(web!=null){web.destroy();web=null;}
    LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(bg);layout.setPadding(32,38,32,25);layout.setGravity(Gravity.TOP);
    TextView title=text("◎ The Self Cult of Agents",26);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);layout.addView(title);
    TextView subtitle=text("Cultivate connection. Discover what becomes possible together.",16);subtitle.setTextColor(Color.rgb(228,188,222));layout.addView(subtitle);
    TextView desc=text("Enter the HTTPS address of your shared Self Cult server. Both participants use the same room address but keep their own private invitation or session key.",15);layout.addView(desc);
    EditText address=new EditText(this);address.setTextColor(fg);address.setHintTextColor(Color.LTGRAY);address.setHint("https://your-network.example");address.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);address.setSingleLine(true);address.setText(prefs.getString("room_url",""));layout.addView(address,new LinearLayout.LayoutParams(-1,-2));
    TextView error=text("",14);error.setTextColor(Color.rgb(255,151,162));layout.addView(error);
    Button connect=new Button(this);connect.setText("Open shared network");layout.addView(connect);
    connect.setOnClickListener(v->{String url=address.getText().toString().trim();if(!url.matches("https://[A-Za-z0-9.-]+(:[0-9]{1,5})?(/.*)?")){error.setText("Use a valid HTTPS address. Local testing can use http://10.0.2.2 when explicitly enabled in a custom build.");return;}prefs.edit().putString("room_url",url).apply();openRoom(url);});
    setContentView(layout);
  }
  private void openRoom(String room){
    try{Uri parsed=Uri.parse(room);allowedOrigin=parsed.getScheme()+"://"+parsed.getAuthority();}
    catch(Exception e){showSetup();return;}
    web=new WebView(this);web.setBackgroundColor(bg);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){Uri dest=req.getUrl();String o=dest.getScheme()+"://"+dest.getAuthority();if(o.equals(allowedOrigin))return false;return true;}
    });
    setContentView(web);web.loadUrl(room);
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else if(web!=null)showSetup();else super.onBackPressed();}
  @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
